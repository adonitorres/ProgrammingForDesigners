<?php 
require('CONFIG.php'); 
require_once('includes/functions.php');
require('includes/header.php');
?>
	<main class="content">
		<h2>Filter by Category (simple JS fetch example)</h2>

		<?php 
		//get all categories that contain posts
		$result = $DB->prepare('SELECT DISTINCT(c.category_id), c.name 
								FROM categories AS c, posts AS p	
								WHERE p.category_id = c.category_id	
								AND p.is_published = 1	') ;
		$result->execute();
		if($result->rowCount() > 0){
			while($row = $result->fetch()){		

				extract($row);
				echo "<button class='category-filter button button-outline' data-catid='$category_id'>$name</button>&nbsp;";
			}
		}else{
			echo 'No Categories to show';
		}?>

		<div class="posts-output grid">
			<?php get_posts_by_category(0); ?>
		</div>


	</main>
<?php 
require('includes/sidebar.php'); ?>


<script type="text/javascript">
//category filter	
document.body.addEventListener('click', function(e){
	if (e.target.classList.contains('category-filter')){
		console.log('click');
		console.log(e.target.dataset.catid)
		fetchPosts(e.target)
	}
});

async function fetchPosts( el ){	
	//get the container that will be updated after liking
	let container = document.querySelector('.posts-output')
	container.classList.add('loading');

	let formData = new FormData()
	formData.append('catId', el.dataset.catid)
	
	let response = await fetch("fetch-handlers/category-filter.php", {
		method:'POST',
	    body: formData
	})
	if (response.ok) {
		let result = await response.text()
	    container.innerHTML = result
		container.classList.remove('loading');
	     
	 } else {
	  	console.log(response.status)
	 }
}
</script>

<?php
require('includes/footer.php');
?>	