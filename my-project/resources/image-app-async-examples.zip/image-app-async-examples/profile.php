<?php 
require('CONFIG.php'); 
require_once('includes/functions.php');
require('includes/header.php');

//whose profile is this?
if(isset($_GET['user_id'])){
	$user_id = clean_int($_GET['user_id']);
}elseif($logged_in_user){
	$user_id = $logged_in_user['user_id'];
}else{
	exit('Invalid User Account');
}

?>
<main class="content">
		<?php 
		//get the user info
		$result = $DB->prepare('SELECT * FROM  users
								WHERE user_id = ?
								LIMIT 1'); 
		$result->execute(array($user_id));

		if( $result->rowCount() >= 1 ){			
			$row = $result->fetch();
			extract($row);		
	?>
	<section class="user author-profile">
		<?php show_profile_pic($profile_pic, 100); ?>
		<h2><?php echo $username ?></h2>
		<p><?php echo $bio; ?></p>
		
		<div class="grid" id="follow-info">
			<?php  follows_interface( $user_id, $logged_in_user['user_id'] ); ?>
		</div>
		<hr>
	</section>
	<?php
			
	//get this user's posts 	
	$result = $DB->prepare('SELECT posts.*,  categories.name
							FROM posts, categories
							WHERE posts.is_published = 1
							AND categories.category_id = posts.category_id
							AND posts.user_id = ?
							ORDER BY posts.date DESC
							LIMIT 20'); 

	$result->execute(array($user_id));
	
	if( $result->rowCount() >= 1 ){			
	?>
	<div class="grid">
	<?php
			while( $row = $result->fetch() ){
				extract($row);
		?>
		<div class="one-post">
			<a href="single.php?post_id=<?php echo $post_id; ?>">
				<?php show_post_image( $image, 'small' ) ?>

			</a>
			<h2><?php echo $row['title']; ?></h2>	

			<span class="category"><?php echo $name; ?></span>
			<span class="date"><?php echo time_ago( $date ); ?></span>
			<span class="comment-count"><?php count_comments( $post_id ); ?></span>
		</div>		

			<?php } //end while loop?>
			</div><!-- .grid -->
		<?php }else{ ?>
		
		<div class="feedback info">
			<p>This user hasn't posted any public images</p>
		</div>

		<?php 
		}//end if posts found 
	}else{
		echo 'Sorry, that user account doesn\'t exist';
	}?>

	</main>
<?php 
require('includes/sidebar.php'); ?>


<?php if( $logged_in_user ){ ?>
	<script type="text/javascript">
		//get the container that will be updated after following
		let container = document.getElementById('follow-info');

		
		document.body.addEventListener('click', function(e){
			if (e.target.classList.contains('follow-button')){
			    follow(e.target);
			}
		});


		async function follow( el ){
				let followee = el.dataset.followee
		   		let follower = <?php echo $logged_in_user['user_id']; ?>;
				console.log(followee, follower)
				let formData = new FormData();
				formData.append('followee', followee);
				formData.append('follower', follower);

				
				let response = await fetch("fetch-handlers/follow.php", {
					method:'POST',
				    body: formData
				});
				if (response.ok) {
					let result = await response.text();  
				      // TODO: update the page now do something with the result
				      console.log('ok');
				      container.innerHTML = result;
				     
				 } else {
				  	alert(response.status);
				 }
			}

		
		
	</script>

<?php } //end if logged in ?>
<?php
require('includes/footer.php');
?>	