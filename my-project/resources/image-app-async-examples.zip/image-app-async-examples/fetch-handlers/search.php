<?php 
require('../config.php');
require('../includes/functions.php');

$phrase = clean_string($_REQUEST['phrase']);

if($phrase != ''){
	$result = $DB->prepare('SELECT * FROM posts 
		WHERE ( title LIKE :phrase
		OR body LIKE :phrase )
		AND is_published = 1
		LIMIT 100');
	$result->execute(array('phrase' => "%$phrase%" ));
	if($result->rowCount()){
		echo '<div class="grid">';
		while($row = $result->fetch()){
			extract($row);
			echo '<div class="item">';
			show_post_image($image, 'small');
			echo "<h2>$title</h2>";
			echo '</div>';
		}
		echo '</div>';

	}else{
		echo 'No Posts match';
	}

}else{
	echo 'No Posts to Show';
}