<?php
/**
 * Handler file for filtering posts by category
 * This file stays behind-the-scenes on the server
 */
//load assets
require('../CONFIG.php');
require_once('../includes/functions.php');

//test slow response
//sleep(1);

//incoming data from JS. sanitize and validate
$cat_id = filter_var($_REQUEST['catId'], FILTER_SANITIZE_NUMBER_INT);

//output
get_posts_by_category($cat_id);