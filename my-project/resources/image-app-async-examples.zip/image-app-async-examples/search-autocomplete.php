<?php 
require('config.php'); 
require_once('includes/functions.php');
require('includes/header.php');
?> 
<main class="content">
	<input type="search" name="phrase" class="search-field" placeholder="Search for posts">
	<div class="output">Search for a keyword above</div>
</main>

<?php require('includes/sidebar.php'); ?>

<script type="text/javascript">
//search autocomplete
document.querySelector('.search-field').addEventListener('input', function(e){
	updateSearch(e.target)
});

async function updateSearch( el ){
	let phrase = el.value;
	console.log(phrase);
	//get the container that will be updated after liking
	let container = document.querySelector('.output');
	container.classList.add('loading');
	//console.log(postId, userId)
	let formData = new FormData()
	formData.append('phrase', phrase)
	
	let response = await fetch("fetch-handlers/search.php", {
		method:'POST',
	    body: formData
	})
	if (response.ok) {
		let result = await response.text()
	    // console.log('ok')
	    container.innerHTML = result
		container.classList.remove('loading');

	     
	 } else {
	  	console.log(response.status)
	 }
}
</script>
<?php require('includes/footer.php'); ?>