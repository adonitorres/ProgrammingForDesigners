	<footer class="footer"></footer>
</div><!-- end .site -->
<?php include('includes/debug-output.php'); ?>
</body>
</html>