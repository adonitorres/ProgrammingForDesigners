<?php
require('CONFIG.php');
require_once('includes/functions.php');
require('includes/header.php');

if( ! $logged_in_user ){
    die( 'You must be logged in to see this page' );
}

?>

<main class="content">
  
        <div id="friends-container">
        <?php show_friends($logged_in_user['user_id']); ?>             
        </div>    
  
</main>



<?php if( $logged_in_user ){ ?>
	<script type="text/javascript">
		//get the container that will be updated after friending
		let container = document.getElementById('friends-container');

		
		document.body.addEventListener('click', function(e){
			if (e.target.className == 'add-friend'){
			   //console.log(e.target.dataset.friendee);
			   friendRequest(e.target)
			}
		});


		async function friendRequest( el ){
				let friendee = el.dataset.friendee
		   		let friender = <?php echo $logged_in_user['user_id']; ?>;
				console.log(friendee, friender)
				let formData = new FormData();
				formData.append('friendee', friendee);
				formData.append('friender', friender);

				
				let response = await fetch("fetch-handlers/friend-request.php", {
					method:'POST',
				    body: formData
				});
				if (response.ok) {
					let result = await response.text();  
				      // TODO: update the page now do something with the result
				      console.log('ok');
				      container.innerHTML = result;
				     
				 } else {
				  	alert(response.status);
				 }
			}

		
		
	</script>

<?php } //end if logged in ?>
<?php
require('includes/footer.php');
?>