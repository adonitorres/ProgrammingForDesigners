TODO
====
* build the search form
* build the search results page
* add pagination to "flip" through the results

* make the user profile template
* make the game post template
* make the "new post" page and parser
* make the edit post page

* add the user and game type to the posts feed
* make logout
* make function to count comments on each post
* make comments work with the logged in person
* make the comments list and form
* make the default profile pic show up in the sidebar (and everywhere needed)


DONE
====
* build the basic home page
* chunk down the header, & footer
* make about us page
* make the TOS page
* write the TOS
* make the login form
* make the register form